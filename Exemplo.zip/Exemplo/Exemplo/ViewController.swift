//
//  ViewController.swift
//  Exemplo
//
//  Created by Usuário Convidado on 16/03/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtAtleta: UITextField!
    
    @IBOutlet weak var txtPeso: UITextField!
   
    @IBOutlet weak var txtAltura: UITextField!
    
    @IBOutlet weak var txtIMC: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Calcular(_ sender: Any) {
        //print("Bom dia 2SIPF")
        
        // Criando o objeto p da classe Pessoa
        let p = Pessoa()
        
        //fazendo o Set no atributo vindo da tela
        p.nome = txtAtleta.text
        p.peso = Float(txtPeso.text!)
        p.altura = Float(txtAltura.text!)
        
        //chamando o métudo calcular
        p.calcular()
        
        // fazendo o Get do IMC para aparecer  na tela 
        txtIMC.text = String(p.imc)
        
    }
    
    
}

